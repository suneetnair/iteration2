#############################################################
#############################################################
############# Coding for Clothes_Washer Table ##############
#############################################################
#############################################################




####### import the needed library 
####### pandas, using df as the main data type to do wrangling
####### time, insert the system current time

import pandas as pd
import time


####### read the csv data
####### the data is downloaded from government website
clothes_washer = pd.read_csv('/Users/cuimingyue/Documents/5120/code/wrangling_data/data_wrangling_v1.1_19:04:2019/cw_2019_04_20.csv')


####### it could use the following code to check the current data
####### coding1: clothes_washer.shape
####### coding2: clothes_washer



####### delete the missing value data
clothes_washer = clothes_washer.dropna(0, how = 'all')
clothes_washer = clothes_washer.dropna(1, how = 'all')



####### add the "updata time" to the table to record the frequency
clothes_washer['Update_time'] = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))



####### rerange the index number
clothes_washer.index = range(len(clothes_washer.index))


####### rename the index name
clothes_washer.index.name = 'Clothes_washer_id'



####### it could use the following code to check the current data
####### coding1: clothes_washer.shape
####### coding2: clothes_washer



####### wirte out the air_conditioner table
clothes_washer.to_csv('/Users/cuimingyue/Documents/5120/code/wrangling_data/data_wrangling_v1.1_19:04:2019/clothes_washer.csv', encoding='utf-8')