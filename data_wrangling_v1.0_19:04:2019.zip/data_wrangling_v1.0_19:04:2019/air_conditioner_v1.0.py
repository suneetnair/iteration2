#############################################################
#############################################################
############# Coding for Air_Conditioner Table ##############
#############################################################
#############################################################




####### import the needed library 
####### pandas, using df as the main data type to do wrangling

import pandas as pd 


####### read the csv data
####### the data is downloaded from government website

air_conditioner = pd.read_csv('/Users/cuimingyue/Documents/5120/code/wrangling_data/ac_2019_04_19.csv')

####### it could use the following code to check the current data
####### coding1: air_conditioner.shape
####### coding2: air_conditioner


####### delete the missing value data
air_conditioner = air_conditioner.dropna(0, how = 'all')
air_conditioner = air_conditioner.dropna(1, how = 'all')


####### choose the “window wall” type as our data source
air_conditioner = air_conditioner.loc[air_conditioner['Configuration2'] == 'Window Wall']


####### add the "updata time" to the table to record the frequency
air_conditioner['Update_year'] = '2019'


####### rerange the index number
air_conditioner.index = range(len(air_conditioner.index))


####### rename the index name
air_conditioner.index.name = 'air_conditioner_id'


####### it could use the following code to check the current data
####### coding1: air_conditioner.shape
####### coding2: air_conditioner



####### wirte out the air_conditioner table
air_conditioner.to_csv('./air_conditioner.csv', encoding='utf-8')